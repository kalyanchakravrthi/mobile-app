$(document).ready(function () {
    $('.gn-clk').click(function (e) {
        $('.gender-blk').stop(true).slideToggle();
    });
    $(document).click(function (e) {
        if (!$(e.target).closest('.gn-clk, .gender-blk').length) {
            $('.gender-blk').stop(true).slideUp();
        }
    });
});

$(document).ready(function () {
    $('.location-bkl').click(function (e) {
        $('.gender-blk-one').stop(true).slideToggle();
    });
    $(document).click(function (e) {
        if (!$(e.target).closest('.location-bkl, .gender-blk-one').length) {
            $('.gender-blk-one').stop(true).slideUp();
        }
    });
});